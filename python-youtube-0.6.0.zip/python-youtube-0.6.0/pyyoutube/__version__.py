# d8888b. db    db d888888b db   db  .d88b.  d8b   db db    db  .d88b.  db    db d888888b db    db d8888b. d88888b
# 88  `8D `8b  d8' `~~88~~' 88   88 .8P  Y8. 888o  88 `8b  d8' .8P  Y8. 88    88 `~~88~~' 88    88 88  `8D 88'
# 88oodD'  `8bd8'     88    88ooo88 88    88 88V8o 88  `8bd8'  88    88 88    88    88    88    88 88oooY' 88ooooo
# 88~~~      88       88    88~~~88 88    88 88 V8o88    88    88    88 88    88    88    88    88 88~~~b. 88~~~~~
# 88         88       88    88   88 `8b  d8' 88  V888    88    `8b  d8' 88b  d88    88    88b  d88 88   8D 88.
# 88         YP       YP    YP   YP  `Y88P'  VP   V8P    YP     `Y88P'  ~Y8888P'    YP    ~Y8888P' Y8888P' Y88888P


VERSION = (0, 6, 0)

__version__ = ".".join(map(str, VERSION))
